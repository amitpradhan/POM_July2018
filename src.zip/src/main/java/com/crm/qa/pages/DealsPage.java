package com.crm.qa.pages;

import com.crm.qa.base.TestBase;

public class DealsPage extends TestBase{

}
