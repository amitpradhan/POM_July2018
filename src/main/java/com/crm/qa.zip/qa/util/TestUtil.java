package com.crm.qa.util;

import org.openqa.selenium.WebElement;

import com.crm.qa.base.TestBase;

public class TestUtil extends TestBase{
	
	public static long PAGE_LOAD_TIMEOUT=60;
	public static long IMPLICIT_WAIT=20;
	
	//"mainpanel" is the frame name for main frame 
		public void switchToFrame(String frameName){
			driver.switchTo().frame(frameName);
		}
		
		public void switchToFrameUsingFrameNo(int frameNo){
			
		}
		public void switchToFrameUsingWebElement(WebElement frame){
			
		}


}
